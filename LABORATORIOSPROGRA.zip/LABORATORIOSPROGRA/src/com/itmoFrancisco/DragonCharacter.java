package com.itmoFrancisco;
/**
 * DragonCharacter enum
 * @author: Francisco Estrella
 * @version: 0.1
 */
public enum DragonCharacter {
    EVIL,
    GOOD,
    CHAOTIC,
    FICKLE;
}

