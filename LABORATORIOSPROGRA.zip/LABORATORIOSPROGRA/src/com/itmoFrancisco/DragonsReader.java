package com.itmoFrancisco;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Hashtable;

public class DragonsReader {

    public Hashtable<Long, Dragon> read(String data) {
        data = removeHeader(data);
        if (data == null)
            return null;
        return getDragons(data, "dragons");
    }

    private Hashtable<Long, Dragon> getDragons(String data, String tagName) {
        String body = getBody(data, tagName);
        if (body == null)
            return null;
        Hashtable<Long, Dragon> dragons = new Hashtable<>();
        while (body.length() > 0) {
            Dragon dragon = getDragon(body, "dragon");
            if (dragon != null)
                dragons.put(dragon.getId(), dragon);
        }
        return dragons;
    }

    private Dragon getDragon(String data, String tagName) {
        String body = getBody(data, tagName);
        if (body == null)
            return null;
        Dragon dragon = new Dragon();
        dragon.setId(getLong(body, "id"));
        dragon.setName(getString(body, "name"));
        dragon.setAge(getLong(body, "age"));
        dragon.setWeight(getDouble(body, "weight"));
        dragon.setCreationDate(getZonedDateTime(body, "creationDate"));
        dragon.setSpeaking(getBoolean(body, "speaking"));
        dragon.setCoordinates(getCoordinates(body, "coordinates"));
        dragon.setCharacter(getCharacter(body, "character"));
        dragon.setKiller(getKiller(body, "killer"));
        return dragon;
    }

    private Person getKiller(String data, String tagName) {
        String body = getBody(data, tagName);
        if (body == null)
            return null;
        Person killer = new Person();
        killer.setName(getString(body, "name"));
        killer.setWeight(getLong(body, "weight"));
        killer.setHeight(getDouble(body, "height"));
        killer.setLocation(getLocation(body, "location"));
        return killer;
    }

    private Location getLocation(String data, String tagName) {
        String body = getBody(data, tagName);
        if (body == null)
            return null;
        Location location = new Location();
        location.setName(getString(body, "name"));
        location.setX(getDouble(body, "x"));
        location.setY(getDouble(body, "y"));
        location.setZ(getFloat(body, "z"));
        return location;
    }

    private DragonCharacter getCharacter(String data, String tagName) {
        String body = getBody(data, tagName);
        switch (body) {
            case "CHAOTIC":
                return DragonCharacter.CHAOTIC;
            case "EVIL":
                return DragonCharacter.EVIL;
            case "FICKLE":
                return DragonCharacter.FICKLE;
            case "GOOD":
                return DragonCharacter.GOOD;
            default:
                return null;
        }
    }

    private Coordinates getCoordinates(String data, String tagName) {
        String body = getBody(data, tagName);
        if (body == null)
            return null;
        Coordinates coordinates = new Coordinates();
        coordinates.setX(getDouble(body, "x"));
        coordinates.setY(getFloat(body, "y"));
        return coordinates;
    }

    private float getFloat(String data, String tagName) {
        String body = getBody(data, tagName);
        return Float.parseFloat(body);
    }

    private ZonedDateTime getZonedDateTime(String data, String tagName) {
        String body = getBody(data, tagName);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        try {
            return sdf.parse(body).toInstant().atZone(ZoneId.systemDefault());
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }

    private Boolean getBoolean(String data, String tagName) {
        String body = getBody(data, tagName);
        return Boolean.parseBoolean(body);
    }

    private double getDouble(String data, String tagName) {
        String body = getBody(data, tagName);
        return Double.parseDouble(body);
    }

    private Long getLong(String data, String tagName) {
        String body = getBody(data, tagName);
        return Long.parseLong(body);
    }

    private String getString(String data, String tagName) {
        return getBody(data, tagName);
    }

    private String getBody(String data, String tagName) {
        String openTag = String.format("<%s>", tagName);
        Integer openTagIndex = data.indexOf(openTag + "\n");
        Integer endOpenTagIndex = 0;
        if (openTagIndex < 0) {
            openTagIndex = data.indexOf(openTag);
            if (openTagIndex < 0)
                return null;
            endOpenTagIndex = openTagIndex + openTag.length();
        } else {
            endOpenTagIndex = openTagIndex + openTag.length() + "\n".length();
        }

        String closeTag = String.format("</%s>", tagName);
        Integer closeTagIndex = data.indexOf(closeTag + "\n");
        Integer endCloseTagIndex;
        if (closeTagIndex < 0) {
            closeTagIndex = data.indexOf(closeTag);
            if (closeTagIndex < 0)
                return null;
            endCloseTagIndex = closeTagIndex + closeTag.length();
        } else {
            endCloseTagIndex = closeTagIndex + closeTag.length() + "\n".length();
        }
        String body = data.substring(endOpenTagIndex + 1, closeTagIndex);
        data = data.substring(endCloseTagIndex);
        return body;
    }

    private String removeHeader(String data) {
        String header = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>";
        if (data.substring(0, data.indexOf("\n")).trim().equals(header))
            return data.substring(data.indexOf("\n") + 1);
        return null;
    }
}
